このフォルダには以下のファイルが入っています

・IDcard.stl
・IDcard.gcode(3Dプリンター)
・IDcard.dxf（改変用 fusion360からdxfを挿入でスケッチを入れれます。外側3.5㎜と内側3㎜）
・IDcard枠.eps（UV枠）
・IDカード.ai(レーザー用。完全なるおまけです)

UVプリンターの使い方は下記のサイトを参照にしてください。
https://xatsukix.github.io/xbp/digi_fab/e3.html

またUVデザインは枠を別名保存して作ってください。

